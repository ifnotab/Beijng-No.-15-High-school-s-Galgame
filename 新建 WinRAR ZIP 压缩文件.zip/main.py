# main.py
from royal_navy import RoyalNavyApp

if __name__ == "__main__":
    RoyalNavyApp().mainloop()
