import tkinter as tk
from tkinter import ttk, messagebox, PhotoImage
from enum import Enum
import random
import time
import pygame

class CardCanvas(tk.Canvas):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.card_width = 80
        self.card_height = 120
        
    def draw_card(self, x, y, value=None, suit=None, face_up=True):
        if face_up and value and suit:
            try:
                # 尝试加载图片
                img = PhotoImage(file=f"cards/{value}{suit}.png")
                img = img.subsample(2, 2)  # 缩小图片
                return self.create_image(x, y, image=img, anchor=tk.NW)
            except:
                # 图片加载失败时使用默认图形
                fill = 'white'
                card = self.create_rectangle(x, y, x+self.card_width, y+self.card_height,
                                          fill=fill, outline='black')
                color = 'red' if suit in ['♥','♦'] else 'black'
                self.create_text(x+self.card_width//2, y+self.card_height//2,
                               text=f"{value}{suit}", font=('Arial', 14), fill=color)
                return card
        else:
            # 显示牌背
            try:
                img = PhotoImage(file="cards/card_back.png")
                img = img.subsample(2, 2)
                return self.create_image(x, y, image=img, anchor=tk.NW)
            except:
                card = self.create_rectangle(x, y, x+self.card_width, y+self.card_height,
                                          fill='navy', outline='black')
                self.create_text(x+self.card_width//2, y+self.card_height//2,
                               text="?", font=('Arial', 14), fill='white')
                return card

class BlackjackFrame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller

        # 获取当前用户筹码
        self.user_chips = self.controller.user_manager.users[self.controller.current_user]['chips']
        # 游戏信息显示
        self.info_label = ttk.Label(self, text=f"21点游戏 - 筹码: {self.user_chips}", font=('Arial', 14))
        self.info_label.pack(pady=10)
        
        # 下注控制
        self.bet_frame = tk.Frame(self)
        self.bet_frame.pack(pady=10)
        
        ttk.Label(self.bet_frame, text="下注金额:").pack(side='left')
        self.bet_var = tk.IntVar(value=10)
        self.bet_entry = ttk.Entry(self.bet_frame, textvariable=self.bet_var, width=5)
        self.bet_entry.pack(side='left', padx=5)
        ttk.Button(self.bet_frame, text="开始游戏", command=self.start_game).pack(side='left', padx=5)
        
        # 游戏画布
        self.canvas = CardCanvas(self, width=800, height=400, bg='green')
        self.canvas.pack(pady=10)
        
        # 游戏控制按钮
        self.controls = tk.Frame(self)
        self.controls.pack(pady=10)
        
        self.hit_btn = ttk.Button(self.controls, text="要牌", command=self.hit, state='disabled')
        self.hit_btn.pack(side='left', padx=5)
        self.stand_btn = ttk.Button(self.controls, text="停牌", command=self.stand, state='disabled')
        self.stand_btn.pack(side='left', padx=5)
        ttk.Button(self.controls, text="返回", command=self.back).pack(side='right', padx=5)
    
    def start_game(self):
        try:
            bet_amount = self.bet_var.get()
            if bet_amount <= 0:
                messagebox.showerror("错误", "下注金额必须大于0")
                return

            # 检查用户是否有足够筹码
            if bet_amount > self.user_chips:
                messagebox.showerror("错误", "筹码不足！")
                return            

            # 播放音效
            try:
                pygame.mixer.Sound("sounds/deal_card.wav").play()
            except:
                pass
            
            self.deck = self.create_deck()
            random.shuffle(self.deck)
            self.player_hand = []
            self.dealer_hand = []
            self.player_score = 0
            self.dealer_score = 0
            
            # 发初始牌
            for _ in range(2):
                self.player_hand.append(self.deck.pop())
                self.dealer_hand.append(self.deck.pop())
            
            self.update_display()
            self.hit_btn.config(state='normal')
            self.stand_btn.config(state='normal')
            self.bet_entry.config(state='disabled')
            
            # 检查玩家是否直接21点
            self.player_score = self.calculate_score(self.player_hand)
            if self.player_score == 21:
                self.stand()
        
        except Exception as e:
            messagebox.showerror("错误", f"游戏开始失败: {str(e)}")
    
    def create_deck(self):
        return [(value, suit) for suit in ['♠','♥','♦','♣'] 
                for value in ['A','2','3','4','5','6','7','8','9','10','J','Q','K']]
    
    def update_display(self):
        self.canvas.delete("all")
        
        # 显示庄家牌（第一张隐藏）
        self.canvas.draw_card(50, 50, *self.dealer_hand[0], face_up=False)
        self.canvas.draw_card(150, 50, *self.dealer_hand[1], face_up=False)
        
        # 显示玩家牌
        for i, card in enumerate(self.player_hand):
            self.canvas.draw_card(50 + i*100, 250, *card)
        
        # 显示分数
        self.player_score = self.calculate_score(self.player_hand)
        self.canvas.create_text(700, 300, text=f"玩家分数: {self.player_score}", 
                               font=('Arial', 14), fill='white')
    
    def hit(self):
        try:
            # 播放音效
            try:
                pygame.mixer.Sound("sounds/deal_card.wav").play()
            except:
                pass
            
            self.player_hand.append(self.deck.pop())
            self.update_display()
            
            self.player_score = self.calculate_score(self.player_hand)
            if self.player_score > 21:
                self.game_over("爆牌！你输了", False)
        except Exception as e:
            messagebox.showerror("错误", f"要牌失败: {str(e)}")
    
    def stand(self):
        try:
            # 播放音效
            try:
                pygame.mixer.Sound("sounds/deal_card.wav").play()
            except:
                pass
            
            # 庄家要牌
            self.dealer_score = self.calculate_score(self.dealer_hand)
            while self.dealer_score < 17:
                self.dealer_hand.append(self.deck.pop())
                self.dealer_score = self.calculate_score(self.dealer_hand)
            
            # 显示庄家所有牌
            self.canvas.delete("all")
            for i, card in enumerate(self.dealer_hand):
                self.canvas.draw_card(50 + i*100, 50, *card)
            
            for i, card in enumerate(self.player_hand):
                self.canvas.draw_card(50 + i*100, 250, *card)
            
            # 显示分数
            self.canvas.create_text(700, 100, text=f"庄家分数: {self.dealer_score}", 
                                   font=('Arial', 14), fill='white')
            self.canvas.create_text(700, 300, text=f"玩家分数: {self.player_score}", 
                                   font=('Arial', 14), fill='white')
            
            # 判断胜负
            bet_amount = self.bet_var.get()
            if self.player_score > 21:
                self.game_over("玩家爆牌！庄家赢", False)
            elif self.dealer_score > 21:
                self.game_over("庄家爆牌！玩家赢", True)
            elif self.player_score > self.dealer_score:
                self.game_over("玩家赢！", True)
            elif self.player_score == self.dealer_score:
                self.game_over("平局！", None)
            else:
                self.game_over("庄家赢！", False)
        
        except Exception as e:
            messagebox.showerror("错误", f"停牌失败: {str(e)}")
    
    def calculate_score(self, hand):
        score = 0
        ace_count = 0
        
        for card in hand:
            value = card[0]
            if value in ['J', 'Q', 'K']:
                score += 10
            elif value == 'A':
                score += 11
                ace_count += 1
            else:
                score += int(value)
        
        # 处理A的特殊情况
        while score > 21 and ace_count > 0:
            score -= 10
            ace_count -= 1
        
        return score
    
    def game_over(self, message, win):
        # 播放音效
        try:
            if win is True:
                pygame.mixer.Sound("sounds/win.wav").play()
            elif win is False:
                pygame.mixer.Sound("sounds/lose.wav").play()
            else:
                pygame.mixer.Sound("sounds/draw.wav").play()
        except:
            pass
        
        # 更新筹码
        bet_amount = self.bet_var.get()
        if win is True:
            # 赢了获得双倍下注
            self.controller.user_manager.update_chips(self.controller.current_user, bet_amount * 2)
        elif win is False:
            # 输了扣除下注
            self.controller.user_manager.update_chips(self.controller.current_user, -bet_amount)
        else:  # 平局
            # 平局返还下注
            self.controller.user_manager.update_chips(self.controller.current_user, 0)
        
        # 更新本地筹码显示
        self.user_chips = self.controller.user_manager.users[self.controller.current_user]['chips']
        self.info_label.config(text=f"21点游戏 - 筹码: {self.user_chips}")
        
        messagebox.showinfo("游戏结束", message)
        self.reset_game()

    
    def reset_game(self):
        self.hit_btn.config(state='disabled')
        self.stand_btn.config(state='disabled')
        self.bet_entry.config(state='normal')
    
    def back(self):
        self.pack_forget()
        self.controller.show_main_menu()

class PokerFrame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.current_bet = 0
        self.pot = 0
        self.player_folded = False
        
        # 获取当前用户筹码
        self.user_chips = self.controller.user_manager.users[self.controller.current_user]['chips']
        self.info_label = ttk.Label(self, text=f"德州扑克 - 筹码: {self.user_chips}", font=('Arial', 14))
        self.info_label.pack(pady=10)
        
        # 下注控制
        self.bet_frame = tk.Frame(self)
        self.bet_frame.pack(pady=10)
        
        ttk.Label(self.bet_frame, text="下注金额:").pack(side='left')
        self.bet_var = tk.IntVar(value=10)
        self.bet_entry = ttk.Entry(self.bet_frame, textvariable=self.bet_var, width=5)
        self.bet_entry.pack(side='left', padx=5)
        ttk.Button(self.bet_frame, text="开始游戏", command=self.start_game).pack(side='left', padx=5)
        
        # 游戏画布
        self.canvas = CardCanvas(self, width=800, height=500, bg='green')
        self.canvas.pack(pady=10)
        
        # 游戏控制按钮
        self.controls = tk.Frame(self)
        self.controls.pack(pady=10)
        
        self.check_btn = ttk.Button(self.controls, text="看牌/跟注", command=self.check_call, state='disabled')
        self.check_btn.pack(side='left', padx=5)
        self.raise_btn = ttk.Button(self.controls, text="加注", command=self.raise_bet, state='disabled')
        self.raise_btn.pack(side='left', padx=5)
        self.fold_btn = ttk.Button(self.controls, text="弃牌", command=self.fold, state='disabled')
        self.fold_btn.pack(side='left', padx=5)
        ttk.Button(self.controls, text="返回", command=self.back).pack(side='right', padx=5)
        
        # 状态标签
        self.status_label = ttk.Label(self, text="点击'开始游戏'开始", font=('Arial', 12))
        self.status_label.pack(pady=10)
        
        # 扑克牌花色和数值
        self.suits = ['♠', '♥', '♦', '♣']
        self.values = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A']
        
    def create_deck(self):
        """创建一副洗好的牌"""
        deck = [(value, suit) for suit in self.suits for value in self.values]
        random.shuffle(deck)
        return deck
    
    def start_game(self):
        """开始新游戏"""
        try:
            # 初始化游戏状态
            self.player_folded = False
            self.current_bet = 0
            self.pot = 0
            self.round = 0  # 0: 翻牌前, 1: 翻牌, 2: 转牌, 3: 河牌
            
            # 获取下注金额
            self.initial_bet = self.bet_var.get()
            if self.initial_bet <= 0:
                messagebox.showerror("错误", "下注金额必须大于0")
                return
            
            if self.initial_bet > self.user_chips:
                messagebox.showerror("错误", "筹码不足！")
                return
            
            # 扣除初始下注
            self.controller.user_manager.update_chips(self.controller.current_user, -self.initial_bet)
            self.user_chips = self.controller.user_manager.users[self.controller.current_user]['chips']
            self.pot += self.initial_bet
            self.current_bet = self.initial_bet
            
            # 创建并洗牌
            self.deck = self.create_deck()
            
            # 发玩家牌
            self.player_hand = [self.deck.pop(), self.deck.pop()]
            
            # 发公共牌 (先发5张但暂时隐藏)
            self.community_cards = []
            for _ in range(5):
                self.community_cards.append(self.deck.pop())
            
            # 电脑玩家 (模拟)
            self.computer_hand = [self.deck.pop(), self.deck.pop()]
            
            # 更新显示
            self.update_display()
            self.status_label.config(text=f"游戏开始！底池: {self.pot} 当前下注: {self.current_bet}")
            
            # 启用按钮
            self.check_btn.config(state='normal')
            self.raise_btn.config(state='normal')
            self.fold_btn.config(state='normal')
            self.bet_entry.config(state='disabled')
            
            # 播放音效
            try:
                pygame.mixer.Sound("sounds/deal_card.wav").play()
            except:
                pass
            
        except Exception as e:
            messagebox.showerror("错误", f"游戏开始失败: {str(e)}")
    
    def update_display(self):
        """更新游戏界面显示"""
        self.canvas.delete("all")
        
        # 显示公共牌 (根据当前轮次)
        self.canvas.create_text(400, 50, text="公共牌", font=('Arial', 12), fill='white')
        cards_to_show = 0 if self.round == 0 else 3 if self.round == 1 else 4 if self.round == 2 else 5
        
        for i in range(cards_to_show):
            x_pos = 300 + i * 100
            self.canvas.draw_card(x_pos, 80, *self.community_cards[i])
        
        # 显示玩家牌
        self.canvas.create_text(400, 300, text="你的手牌", font=('Arial', 12), fill='white')
        for i, card in enumerate(self.player_hand):
            self.canvas.draw_card(350 + i * 100, 330, *card)
        
        # 显示电脑玩家 (背面)
        self.canvas.create_text(400, 150, text="电脑玩家", font=('Arial', 12), fill='white')
        for i in range(2):
            self.canvas.draw_card(350 + i * 100, 180, face_up=False)
        
        # 显示筹码信息
        self.canvas.create_text(700, 400, 
                              text=f"你的筹码: {self.user_chips}\n底池: {self.pot}\n当前下注: {self.current_bet}",
                              font=('Arial', 12), fill='white')
    
    def check_call(self):
        """看牌或跟注"""
        if self.current_bet == 0:
            self.status_label.config(text="你选择了看牌")
            self.computer_turn()
        else:
            # 跟注需要支付与当前下注相同的金额
            if self.current_bet > self.user_chips:
                messagebox.showerror("错误", "筹码不足，无法跟注！")
                return
            
            self.controller.user_manager.update_chips(self.controller.current_user, -self.current_bet)
            self.user_chips = self.controller.user_manager.users[self.controller.current_user]['chips']
            self.pot += self.current_bet
            self.status_label.config(text=f"你选择了跟注 {self.current_bet}")
            self.computer_turn()
    
    def raise_bet(self):
        """加注"""
        try:
            bet_amount = self.bet_var.get()
            if bet_amount <= self.current_bet:
                messagebox.showerror("错误", f"加注金额必须大于当前下注({self.current_bet})")
                return
            
            if bet_amount > self.user_chips:
                messagebox.showerror("错误", "筹码不足！")
                return
            
            # 计算需要额外支付的金额
            additional = bet_amount - self.current_bet
            self.controller.user_manager.update_chips(self.controller.current_user, -additional)
            self.user_chips = self.controller.user_manager.users[self.controller.current_user]['chips']
            self.pot += additional
            self.current_bet = bet_amount
            
            self.status_label.config(text=f"你加注到 {bet_amount}")
            self.computer_turn()
        
        except Exception as e:
            messagebox.showerror("错误", f"加注失败: {str(e)}")
    
    def fold(self):
        """弃牌"""
        self.player_folded = True
        self.status_label.config(text="你选择了弃牌")
        self.game_over(False)
    
    def computer_turn(self):
        """电脑玩家行动"""
        # 简单AI: 随机选择跟注、加注或弃牌
        action = random.choices(
            ['call', 'raise', 'fold'],
            weights=[0.6, 0.3, 0.1],  # 60%跟注, 30%加注, 10%弃牌
            k=1
        )[0]
        
        if action == 'call':
            self.pot += self.current_bet
            self.status_label.config(text=f"电脑玩家跟注 {self.current_bet}")
        elif action == 'raise':
            raise_amount = self.current_bet + random.randint(10, 50)
            self.pot += raise_amount
            self.current_bet = raise_amount
            self.status_label.config(text=f"电脑玩家加注到 {raise_amount}")
        else:  # fold
            self.status_label.config(text="电脑玩家弃牌！")
            self.game_over(True)
            return
        
        # 进入下一轮
        self.next_round()
    
    def next_round(self):
        """进入下一轮"""
        self.round += 1
        
        if self.round == 1:  # 翻牌
            self.status_label.config(text="翻牌阶段 - 请行动")
        elif self.round == 2:  # 转牌
            self.status_label.config(text="转牌阶段 - 请行动")
        elif self.round == 3:  # 河牌
            self.status_label.config(text="河牌阶段 - 请行动")
        else:  # 游戏结束，比较牌型
            self.evaluate_hands()
        
        self.update_display()
    
    def evaluate_hands(self):
        """评估双方牌型并决定胜负"""
        if self.player_folded:
            return  # 玩家已弃牌，无需比较
        
        # 获取双方最终牌型
        player_hand = self.player_hand + self.community_cards
        computer_hand = self.computer_hand + self.community_cards
        
        # 评估牌型强度 (简化版)
        player_strength = self.evaluate_hand_strength(player_hand)
        computer_strength = self.evaluate_hand_strength(computer_hand)
        
        # 比较牌型
        if player_strength > computer_strength:
            self.game_over(True)
        elif player_strength < computer_strength:
            self.game_over(False)
        else:
            self.game_over(None)  # 平局
    
    def evaluate_hand_strength(self, hand):
        """评估牌型强度 (简化版)"""
        values = [card[0] for card in hand]
        suits = [card[1] for card in hand]
        
        value_counts = {value: values.count(value) for value in values}
        suit_counts = {suit: suits.count(suit) for suit in suits}
        
        # 检查同花顺
        if max(suit_counts.values()) >= 5:
            return 8  # 同花顺
        
        # 检查四条
        if max(value_counts.values()) == 4:
            return 7
        
        # 检查葫芦
        if sorted(value_counts.values()) == [2, 3]:
            return 6
        
        # 检查同花
        if max(suit_counts.values()) >= 5:
            return 5
        
        # 检查顺子
        value_order = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A']
        value_indices = sorted([value_order.index(v) for v in value_counts.keys()])
        for i in range(len(value_indices) - 4):
            if value_indices[i+4] - value_indices[i] == 4:
                return 4
        
        # 检查三条
        if max(value_counts.values()) == 3:
            return 3
        
        # 检查两对
        if list(value_counts.values()).count(2) >= 2:
            return 2
        
        # 检查一对
        if max(value_counts.values()) == 2:
            return 1
        
        # 高牌
        return 0
    
    def game_over(self, win):
        """游戏结束处理"""
        if win is True:
            # 赢了获得底池
            self.controller.user_manager.update_chips(self.controller.current_user, self.pot)
            message = f"你赢了！获得 {self.pot} 筹码"
        elif win is False:
            message = "你输了！"
        else:
            # 平局平分底池
            self.controller.user_manager.update_chips(self.controller.current_user, self.pot // 2)
            message = f"平局！你获得 {self.pot // 2} 筹码"
        
        # 更新筹码显示
        self.user_chips = self.controller.user_manager.users[self.controller.current_user]['chips']
        self.info_label.config(text=f"德州扑克 - 筹码: {self.user_chips}")
        
        # 显示电脑玩家的牌
        for i, card in enumerate(self.computer_hand):
            self.canvas.draw_card(350 + i * 100, 180, *card)
        
        # 显示结果
        messagebox.showinfo("游戏结束", message)
        self.reset_game()
    
    def reset_game(self):
        """重置游戏状态"""
        self.check_btn.config(state='disabled')
        self.raise_btn.config(state='disabled')
        self.fold_btn.config(state='disabled')
        self.bet_entry.config(state='normal')
    
    def back(self):
        """返回主菜单"""
        self.pack_forget()
        self.controller.show_main_menu()

class SlotFrame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        
        # 获取当前用户筹码
        self.user_chips = self.controller.user_manager.users[self.controller.current_user]['chips']
        self.info_label = ttk.Label(self, text=f"老虎机 - 筹码: {self.user_chips}", font=('Arial', 14))
        self.info_label.pack(pady=10)        
        # 游戏信息显示
        self.info_label = ttk.Label(self, text=f"老虎机 - 筹码: {self.user_chips}", font=('Arial', 14))
        self.info_label.pack(pady=10)
        
        # 下注控制
        self.bet_frame = tk.Frame(self)
        self.bet_frame.pack(pady=10)
        
        ttk.Label(self.bet_frame, text="下注金额:").pack(side='left')
        self.bet_var = tk.IntVar(value=1)
        self.bet_entry = ttk.Entry(self.bet_frame, textvariable=self.bet_var, width=5)
        self.bet_entry.pack(side='left', padx=5)
        self.spin_btn = ttk.Button(self.bet_frame, text="旋转", command=self.spin)
        self.spin_btn.pack(side='left', padx=5)
        
        # 老虎机显示
        self.slot_frame = tk.Frame(self)
        self.slot_frame.pack(pady=20)
        
        self.slot_labels = []
        for i in range(3):
            label = tk.Label(self.slot_frame, text="?", font=('Arial', 48), width=3, 
                           relief='sunken', bg='white')
            label.grid(row=0, column=i, padx=10)
            self.slot_labels.append(label)
        
        # 结果标签
        self.result_label = ttk.Label(self, text="", font=('Arial', 16))
        self.result_label.pack(pady=10)
        
        # 返回按钮
        ttk.Button(self, text="返回", command=self.back).pack(pady=10)
        
        # 老虎机符号
        self.symbols = ['🍒', '🍋', '🍊', '🍇', '🔔', '⭐', '[]']
    
    def spin(self):
        try:
            bet_amount = self.bet_var.get()
            if bet_amount <= 0:
                messagebox.showerror("错误", "下注金额必须大于0")
                return
            
            # 检查用户是否有足够筹码
            if bet_amount > self.user_chips:
                messagebox.showerror("错误", "筹码不足！")
                return
            
            # 播放音效
            try:
                pygame.mixer.Sound("sounds/slot_spin.wav").play()
            except:
                pass
            
            # 禁用按钮
            self.spin_btn.config(state='disabled')
            self.bet_entry.config(state='disabled')
            self.result_label.config(text="旋转中...")
            
            # 动画效果
            self.spinning = True
            self.spin_count = 0
            self.final_results = []
            self.animate_spin()
        
        except Exception as e:
            messagebox.showerror("错误", f"旋转失败: {str(e)}")
    
    def animate_spin(self):
        if self.spin_count < 10:  # 旋转10次
            for i in range(3):
                symbol = random.choice(self.symbols)
                self.slot_labels[i].config(text=symbol)
            self.spin_count += 1
            self.after(100, self.animate_spin)
        else:
            # 最终结果
            self.final_results = [random.choice(self.symbols) for _ in range(3)]
            for i, symbol in enumerate(self.final_results):
                self.slot_labels[i].config(text=symbol)
            
            # 检查结果
            self.check_result()
            self.spin_btn.config(state='normal')
            self.bet_entry.config(state='normal')
    
    def check_result(self):
        # 简单实现 - 检查是否三个相同
        if self.final_results[0] == self.final_results[1] == self.final_results[2]:
            # 播放音效
            try:
                pygame.mixer.Sound("sounds/win.wav").play()
            except:
                pass
            
            win_amount = self.bet_var.get() * 5  # 5倍奖励
            self.controller.user_manager.update_chips(self.controller.current_user, win_amount)
            self.result_label.config(text=f"恭喜！三个相同，你赢了{win_amount}筹码！", foreground='green')
        elif self.final_results[0] == self.final_results[1] or \
             self.final_results[1] == self.final_results[2]:
            win_amount = self.bet_var.get() * 2  # 2倍奖励
            self.controller.user_manager.update_chips(self.controller.current_user, win_amount)
            self.result_label.config(text=f"两个相同，小赢{win_amount}筹码！", foreground='blue')
        else:
            loss_amount = self.bet_var.get()
            self.controller.user_manager.update_chips(self.controller.current_user, -loss_amount)
            self.result_label.config(text=f"很遗憾，没有匹配，损失{loss_amount}筹码", foreground='red')
        
        # 更新本地筹码显示
        self.user_chips = self.controller.user_manager.users[self.controller.current_user]['chips']
        self.info_label.config(text=f"老虎机 - 筹码: {self.user_chips}")
        
    def back(self):
        self.pack_forget()
        self.controller.show_main_menu()

# 定义牌型常量
SINGLE = 1  # 单张
PAIR = 2    # 对子
TRIPLE = 3  # 三张
STRAIGHT = 4  # 顺子
CONSECUTIVE_PAIRS = 5  # 连对
AIRPLANE = 6  # 飞机
BOMB = 7     # 炸弹
THREE_WITH_ONE = 8  # 三带一
THREE_WITH_TWO = 9  # 三带二

# 牌的大小顺序
RANK_ORDER = {
    '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8,
    '9': 9, '10': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14,
    '2': 15, '小王': 16, '大王': 17
}

# 花色映射
SUIT_MAP = {
    '♠': '黑桃',
    '♥': '红桃',
    '♦': '方块',
    '♣': '梅花'
}

class LandlordFrame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        
        # 获取当前用户筹码
        self.user_chips = self.controller.user_manager.users[self.controller.current_user]['chips']
        self.info_label = ttk.Label(self, text=f"斗地主 - 筹码: {self.user_chips}", font=('Arial', 14))
        self.info_label.pack(pady=10)
        
        # 玩家区域
        self.player_frame = tk.Frame(self)
        self.player_frame.pack(pady=20, fill='x')
        
        # 电脑玩家区域
        self.computer_frame = tk.Frame(self)
        self.computer_frame.pack(pady=20, fill='x')
        
        # 控制按钮
        self.controls = tk.Frame(self)
        self.controls.pack(pady=20)
        
        ttk.Button(self.controls, text="开始游戏", command=self.start_game).pack(side='left', padx=5)
        self.play_btn = ttk.Button(self.controls, text="出牌", command=self.play_card, state='disabled')
        self.play_btn.pack(side='left', padx=5)
        self.pass_btn = ttk.Button(self.controls, text="不出", command=self.pass_turn, state='disabled')
        self.pass_btn.pack(side='left', padx=5)
        ttk.Button(self.controls, text="返回", command=self.back).pack(side='right', padx=5)
        
        # 状态标签
        self.status_label = ttk.Label(self, text="点击'开始游戏'开始", font=('Arial', 12))
        self.status_label.pack(pady=10)
        
        # 扑克牌花色和数值
        self.suits = ['♠', '♥', '♦', '♣']
        self.values = ['3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A', '2']
        
        # 游戏状态
        self.base_bet = 50  # 基础下注
        self.is_landlord = False  # 是否是地主
        self.last_played = None  # 最后出牌的玩家
    
    def create_deck(self):
        """创建一副洗好的牌"""
        deck = [(value, suit) for suit in self.suits for value in self.values]
        deck += [('小王', ''), ('大王', '')]  # 添加大小王
        random.shuffle(deck)
        return deck
    
    def start_game(self):
        """开始新游戏"""
        try:
            # 检查筹码是否足够
            if self.base_bet > self.user_chips:
                messagebox.showerror("错误", "筹码不足！")
                return
            
            # 播放音效
            try:
                pygame.mixer.Sound("sounds/deal_card.wav").play()
            except:
                pass
            
            # 扣除基础下注
            self.controller.user_manager.update_chips(self.controller.current_user, -self.base_bet)
            self.user_chips = self.controller.user_manager.users[self.controller.current_user]['chips']
            self.info_label.config(text=f"斗地主 - 筹码: {self.user_chips}")
            
            # 创建并洗牌
            self.deck = self.create_deck()
            
            # 发牌
            self.player_hand = self.deck[:17]
            self.computer1_hand = self.deck[17:34]
            self.computer2_hand = self.deck[34:51]
            self.landlord_cards = self.deck[51:]
            
            # 随机决定地主 (简化版)
            self.is_landlord = random.choice([True, False, False])
            if self.is_landlord:
                self.player_hand += self.landlord_cards
                self.status_label.config(text="你是地主！请先出牌")
            else:
                # 随机选择一个电脑玩家当地主
                if random.choice([True, False]):
                    self.computer1_hand += self.landlord_cards
                    self.status_label.config(text="电脑玩家1是地主！等待出牌...")
                else:
                    self.computer2_hand += self.landlord_cards
                    self.status_label.config(text="电脑玩家2是地主！等待出牌...")
            
            # 排序手牌
            self.sort_hand(self.player_hand)
            self.sort_hand(self.computer1_hand)
            self.sort_hand(self.computer2_hand)
            
            # 更新显示
            self.update_display()
            
            # 启用按钮
            self.play_btn.config(state='normal')
            self.pass_btn.config(state='normal')
            
            # 如果是电脑先出牌
            if not self.is_landlord:
                self.after(1000, self.computer_play)
        
        except Exception as e:
            messagebox.showerror("错误", f"游戏开始失败: {str(e)}")
    
    def sort_hand(self, hand):
        """排序手牌"""
        value_order = ['3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A', '2', '小王', '大王']
        hand.sort(key=lambda card: value_order.index(card[0]))
    
    def update_display(self):
        """更新游戏界面显示"""
        # 清空之前的显示
        for widget in self.player_frame.winfo_children():
            widget.destroy()
        
        for widget in self.computer_frame.winfo_children():
            widget.destroy()
        
        # 显示玩家手牌
        ttk.Label(self.player_frame, text="你的手牌:").pack(anchor='w')
        card_frame = tk.Frame(self.player_frame)
        card_frame.pack(fill='x')
        
        for card in self.player_hand:
            label = ttk.Label(card_frame, text=f"{card[0]}{card[1]}", 
                             width=3, relief='raised')
            label.pack(side='left', padx=2)
        
        # 显示电脑玩家
        ttk.Label(self.computer_frame, text="电脑玩家1:").pack(anchor='w')
        comp1_label = ttk.Label(self.computer_frame, text=f"剩余 {len(self.computer1_hand)} 张牌")
        comp1_label.pack(anchor='w')
        
        ttk.Label(self.computer_frame, text="电脑玩家2:").pack(anchor='w', pady=(10,0))
        comp2_label = ttk.Label(self.computer_frame, text=f"剩余 {len(self.computer2_hand)} 张牌")
        comp2_label.pack(anchor='w')
        
        # 显示地主牌
        ttk.Label(self.computer_frame, text="地主牌:").pack(anchor='w', pady=(10,0))
        landlord_label = ttk.Label(self.computer_frame, text=f"{self.landlord_cards[0][0]}{self.landlord_cards[0][1]} ...")
        landlord_label.pack(anchor='w')
        
        # 显示当前玩家身份
        role_label = ttk.Label(self.computer_frame, 
                              text="你是地主" if self.is_landlord else "你是农民",
                              font=('Arial', 12, 'bold'))
        role_label.pack(anchor='w', pady=(10,0))
    
    def play_card(self):
        """玩家出牌 (简化版)"""
        if not self.player_hand:
            return
        
        # 简单实现 - 随机出一张牌
        card = random.choice(self.player_hand)
        self.player_hand.remove(card)
        
        # 更新显示
        self.update_display()
        self.status_label.config(text=f"你出了 {card[0]}{card[1]}")
        
        # 检查是否获胜
        if not self.player_hand:
            self.game_over(True)
            return
        
        # 电脑出牌
        self.after(1000, self.computer_play)
    
    def computer_play(self):
        """电脑玩家出牌 (简化版)"""
        # 随机选择一个电脑玩家出牌
        if random.choice([True, False]):
            hand = self.computer1_hand
            player_name = "电脑玩家1"
        else:
            hand = self.computer2_hand
            player_name = "电脑玩家2"
        
        if not hand:
            return
        
        # 简单实现 - 随机出一张牌
        card = random.choice(hand)
        hand.remove(card)
        
        # 更新显示
        self.update_display()
        self.status_label.config(text=f"{player_name} 出了 {card[0]}{card[1]}")
        
        # 检查是否获胜
        if not hand:
            self.game_over(False)
            return
    
    def pass_turn(self):
        """玩家选择不出"""
        self.status_label.config(text="你选择不出")
        # 电脑出牌
        self.after(1000, self.computer_play)
    
    def game_over(self, player_won):
        """游戏结束处理"""
        if player_won:
            # 赢了获得3倍基础下注
            win_amount = self.base_bet * 3
            self.controller.user_manager.update_chips(self.controller.current_user, win_amount)
            message = f"恭喜！你赢了！获得 {win_amount} 筹码"
        else:
            message = "很遗憾，你输了！"
        
        # 更新筹码显示
        self.user_chips = self.controller.user_manager.users[self.controller.current_user]['chips']
        self.info_label.config(text=f"斗地主 - 筹码: {self.user_chips}")
        
        # 显示结果
        messagebox.showinfo("游戏结束", message)
        self.reset_game()
    
    def reset_game(self):
        """重置游戏状态"""
        self.play_btn.config(state='disabled')
        self.pass_btn.config(state='disabled')
    
    def back(self):
        """返回主菜单"""
        self.pack_forget()
        self.controller.show_main_menu()

class RPSFrame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        
        # 获取当前用户筹码
        self.user_chips = self.controller.user_manager.users[self.controller.current_user]['chips']
        self.info_label = ttk.Label(self, text=f"石头剪刀布 - 筹码: {self.user_chips}", font=('Arial', 14))
        self.info_label.pack(pady=10)
        
        # 下注控制
        self.bet_frame = tk.Frame(self)
        self.bet_frame.pack(pady=10)
        
        ttk.Label(self.bet_frame, text="下注金额:").pack(side='left')
        self.bet_var = tk.IntVar(value=10)
        ttk.Entry(self.bet_frame, textvariable=self.bet_var, width=5).pack(side='left', padx=5)
        
        ttk.Button(self.choice_frame, text="✊", command=lambda: self.play(0), 
                 width=5).pack(side='left', padx=10)
        ttk.Button(self.choice_frame, text="✋", command=lambda: self.play(1), 
                 width=5).pack(side='left', padx=10)
        ttk.Button(self.choice_frame, text="✌️", command=lambda: self.play(2), 
                 width=5).pack(side='left', padx=10)
        
        self.result_label = ttk.Label(self, text="", font=('Arial', 16))
        self.result_label.pack(pady=20)
        
        ttk.Button(self, text="返回", command=self.back).pack(pady=20)
    
    def play(self, player_choice):
        try:
            bet_amount = self.bet_var.get()
            if bet_amount <= 0:
                messagebox.showerror("错误", "下注金额必须大于0")
                return
            
            if bet_amount > self.user_chips:
                messagebox.showerror("错误", "筹码不足！")
                return
        except:
            pass
        try:
            # 播放音效
            try:
                pygame.mixer.Sound("sounds/rps.wav").play()
            except:
                pass
            
            choices = ['✊', '✋', '✌️']
            computer_choice = random.randint(0, 2)
            
            result = (player_choice - computer_choice) % 3
            if result == 0:  # 平局
                self.result_label.config(text=f"平局！筹码不变", foreground="blue")
            elif result == 1:  # 玩家赢
                win_amount = bet_amount * 2  # 2倍奖励
                self.controller.user_manager.update_chips(self.controller.current_user, win_amount)
                self.result_label.config(text=f"你赢了！获得{win_amount}筹码", foreground="green")
            else:  # 玩家输
                self.controller.user_manager.update_chips(self.controller.current_user, -bet_amount)
                self.result_label.config(text=f"你输了！损失{bet_amount}筹码", foreground="red")
            
            # 更新本地筹码显示
            self.user_chips = self.controller.user_manager.users[self.controller.current_user]['chips']
            self.info_label.config(text=f"石头剪刀布 - 筹码: {self.user_chips}")
        
        except Exception as e:
            messagebox.showerror("错误", f"游戏失败: {str(e)}")
    
    def back(self):
        self.pack_forget()
        self.controller.show_main_menu()
