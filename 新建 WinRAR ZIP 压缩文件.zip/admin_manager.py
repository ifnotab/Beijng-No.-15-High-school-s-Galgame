# admin_manager.py
import os
import json
from cryptography.fernet import Fernet
import hashlib

class AdminManager:
    def __init__(self):
        self.admin_key = b'admin_key_placeholder'  # 实际应用中应更安全
        self.cipher = Fernet(Fernet.generate_key())
        self.admin_file = 'admin_credentials.dat'
        self.admin_users = {}
        self.load_admin_users()
        
        # 如果文件不存在，创建默认管理员
        if not os.path.exists(self.admin_file):
            self.add_admin('admin', 'admin123')
    
    def encrypt(self, data):
        return self.cipher.encrypt(json.dumps(data).encode())
    
    def decrypt(self, encrypted):
        return json.loads(self.cipher.decrypt(encrypted).decode())
    
    def load_admin_users(self):
        if os.path.exists(self.admin_file):
            try:
                with open(self.admin_file, 'rb') as f:
                    self.admin_users = self.decrypt(f.read())
            except:
                self.admin_users = {}
                print("管理员数据加载失败")
    
    def save_admin_users(self):
        try:
            with open(self.admin_file, 'wb') as f:
                f.write(self.encrypt(self.admin_users))
        except Exception as e:
            print(f"保存管理员数据失败: {str(e)}")
    
    def add_admin(self, username, password):
        if username in self.admin_users:
            return False
        self.admin_users[username] = {
            'password': hashlib.sha256(password.encode()).hexdigest()
        }
        self.save_admin_users()
        return True
    
    def authenticate(self, username, password):
        admin = self.admin_users.get(username)
        if admin and admin['password'] == hashlib.sha256(password.encode()).hexdigest():
            return True
        return False
    
    def modify_chips(self, username, amount):
        # 实际应用中应调用用户管理器修改筹码
        print(f"管理员修改 {username} 的筹码: {amount}")
        return True

# 测试代码
if __name__ == "__main__":
    admin_mgr = AdminManager()
    print(admin_mgr.authenticate('admin', 'admin123'))
    admin_mgr.modify_chips('test_user', 5000)
